<?php
include "api_client.php";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"] ?? '';
    $password = $_POST["password"] ?? '';
    $res = call_api("/auth/register", "POST", ["email"=>$email, "password"=>$password,"consent_analytics"=>true]);
    if (isset($res["id"])) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Registration error: " . ($res["detail"] ?? json_encode($res));
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Register - Steroid Risk</title></head>
<body>
<h2>Register</h2>
<?php if(!empty($error)){ echo "<p style='color:red;'>$error</p>"; } ?>
<form method="post">
  Email: <input type="email" name="email" required><br><br>
  Password: <input type="password" name="password" required><br><br>
  <button type="submit">Register</button>
</form>
<p><a href="index.php">Back to login</a></p>
</body>
</html>
