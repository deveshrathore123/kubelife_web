PHP Frontend:
- Place these files in your web server (e.g., XAMPP htdocs or run: php -S localhost:8080)
- Ensure the backend FastAPI is running at http://127.0.0.1:8000
- Visit http://localhost:8080/index.php (or appropriate host) to use the app.
