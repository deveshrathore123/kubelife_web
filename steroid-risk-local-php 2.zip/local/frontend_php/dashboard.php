<?php
session_start();
include "api_client.php";
if (!isset($_SESSION["token"])) { header("Location: index.php"); exit; }

$submit_result = null;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $payload = [
        "frequency_per_week" => floatval($_POST["frequency_per_week"] ?? 0),
        "dosage_mg_per_week" => floatval($_POST["dosage_mg_per_week"] ?? 0),
        "cycle_weeks" => intval($_POST["cycle_weeks"] ?? 0),
        "pct_on_cycle" => isset($_POST["pct_on_cycle"]) ? true : false,
        "side_effects" => ["chest_pain"=>isset($_POST["chest_pain"])],
        "lifestyle" => ["alcohol"=>$_POST["alcohol"] ?? "unknown"],
        "weight_kg" => floatval($_POST["weight_kg"] ?? 0),
        "systolic_bp" => intval($_POST["systolic_bp"] ?? 0),
        "diastolic_bp" => intval($_POST["diastolic_bp"] ?? 0),
        "heart_rate_bpm" => intval($_POST["heart_rate_bpm"] ?? 0),
        "mood_1_5" => intval($_POST["mood_1_5"] ?? 3),
        "sleep_hours" => floatval($_POST["sleep_hours"] ?? 7)
    ];
    $submit_result = call_api("/ingest/entry", "POST", $payload, $_SESSION["token"]);
}

$summary = call_api("/analytics/me/summary", "GET", null, $_SESSION["token"]);
$population = call_api("/analytics/population/percentiles", "GET", null, $_SESSION["token"]);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard - Steroid Risk</title></head>
<body>
<h2>Dashboard</h2>
<p><a href="logout.php">Logout</a></p>

<h3>Submit new entry</h3>
<?php if($submit_result){ echo "<pre>" . htmlspecialchars(json_encode($submit_result, JSON_PRETTY_PRINT)) . "</pre>"; } ?>
<form method="post">
  Dosage mg/week: <input type="number" step="0.1" name="dosage_mg_per_week"><br><br>
  Frequency per week: <input type="number" step="1" name="frequency_per_week"><br><br>
  Cycle weeks: <input type="number" name="cycle_weeks"><br><br>
  On cycle now: <input type="checkbox" name="pct_on_cycle"><br><br>
  Chest pain (check if yes): <input type="checkbox" name="chest_pain"><br><br>
  Alcohol level (low/medium/high): <input type="text" name="alcohol"><br><br>
  Weight (kg): <input type="number" step="0.1" name="weight_kg"><br><br>
  Systolic BP: <input type="number" name="systolic_bp"><br><br>
  Diastolic BP: <input type="number" name="diastolic_bp"><br><br>
  Heart rate (bpm): <input type="number" name="heart_rate_bpm"><br><br>
  Mood (1-5): <input type="number" name="mood_1_5" min="1" max="5"><br><br>
  Sleep hours: <input type="number" step="0.1" name="sleep_hours"><br><br>
  <button type="submit">Save Entry</button>
</form>

<h3>Your summary</h3>
<pre><?php echo htmlspecialchars(json_encode($summary, JSON_PRETTY_PRINT)); ?></pre>

<h3>Population stats</h3>
<pre><?php echo htmlspecialchars(json_encode($population, JSON_PRETTY_PRINT)); ?></pre>

</body>
</html>
