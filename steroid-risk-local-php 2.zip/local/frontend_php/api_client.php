<?php
function call_api($endpoint, $method = "GET", $data = null, $token = null) {
    $url = "http://127.0.0.1:8000" . $endpoint;
    $ch = curl_init($url);
    $headers = ["Content-Type: application/json"];
    if ($token) { $headers[] = "Authorization: Bearer $token"; }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if (strtoupper($method) === "POST") {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    } elseif (strtoupper($method) === "PUT") {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        if ($data) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $err = curl_error($ch);
        curl_close($ch);
        return ["error" => $err];
    }
    curl_close($ch);
    $decoded = json_decode($response, true);
    return $decoded === null ? ["raw" => $response] : $decoded;
}
?>