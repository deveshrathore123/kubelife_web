<?php
session_start();
include "api_client.php";
if (!isset($_SESSION["token"])) { header("Location: index.php"); exit; }

$pop = call_api("/analytics/population/percentiles", "GET", null, $_SESSION["token"]);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Analysis - Steroid Risk</title></head>
<body>
<h2>Population Analysis</h2>
<pre><?php echo htmlspecialchars(json_encode($pop, JSON_PRETTY_PRINT)); ?></pre>
<p><a href="dashboard.php">Back</a></p>
</body>
</html>
