import numpy as np
from sklearn.linear_model import LogisticRegression

class SimpleEarlyWarningModel:
    def __init__(self):
        self.model = LogisticRegression()
        X = np.array([
            [200, 1, 120, 80, 70, 8],
            [800, 4, 150, 95, 105, 5],
            [1200, 5, 160, 100, 110, 4],
            [0, 0, 118, 78, 65, 7],
            [500, 2, 135, 88, 85, 6],
            [900, 6, 170, 110, 120, 5],
        ])
        y = np.array([0,1,1,0,0,1])
        self.model.fit(X, y)
    def predict_proba(self, x: dict) -> float:
        arr = np.array([[x.get("dosage_mg_per_week",0), x.get("frequency_per_week",0),
                         x.get("systolic_bp",120) or 120, x.get("diastolic_bp",80) or 80,
                         x.get("heart_rate_bpm",70) or 70, x.get("sleep_hours",7) or 7]])
        return float(self.model.predict_proba(arr)[0][1])

MODEL = SimpleEarlyWarningModel()
