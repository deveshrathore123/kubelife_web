from typing import Dict, Any

def rule_based_score(x: Dict[str, Any]):
    score = 0.0
    notes = []
    dose = (x.get("dosage_mg_per_week") or 0)
    freq = (x.get("frequency_per_week") or 0)
    if dose > 500: 
        score += 2; notes.append("high_dose")
    if dose > 1000: 
        score += 2
    if freq >= 3: 
        score += 1
    wk = (x.get("cycle_weeks") or 0)
    if wk > 8: score += 1
    if wk > 12: score += 1
    sbp = x.get("systolic_bp"); dbp = x.get("diastolic_bp"); hr = x.get("heart_rate_bpm")
    if sbp and sbp >= 140: 
        score += 2; notes.append("elevated_bp")
    if dbp and dbp >= 90: 
        score += 2
    if hr and hr >= 100: 
        score += 1
    mood = x.get("mood_1_5"); sleep = x.get("sleep_hours")
    if mood and mood <= 2: score += 1
    if sleep is not None and sleep < 6: score += 1
    se = (x.get("side_effects") or {})
    if se.get("chest_pain") or se.get("shortness_of_breath"): 
        score += 3; notes.append("urgent_symptom")
    if se.get("jaundice"): score += 2
    band = "low"
    if score >= 6: band = "high"
    elif score >= 3: band = "moderate"
    return {"score": round(score, 2), "band": band, "notes": ",".join(notes)}
