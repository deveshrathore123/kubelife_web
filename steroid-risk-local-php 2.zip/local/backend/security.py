from datetime import datetime, timedelta
from jose import jwt
from passlib.context import CryptContext

SECRET = "dev_change_me"
ALGO = "HS256"
ACCESS_MINUTES = 60 * 12
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(pw: str) -> str:
    return pwd_context.hash(pw)

def verify_password(pw: str, hashed: str) -> bool:
    return pwd_context.verify(pw, hashed)

def make_token(sub: str) -> str:
    exp = datetime.utcnow() + timedelta(minutes=ACCESS_MINUTES)
    return jwt.encode({"sub": sub, "exp": exp}, SECRET, algorithm=ALGO)

def decode_token(token: str) -> str | None:
    try:
        return jwt.decode(token, SECRET, algorithms=[ALGO]).get("sub")
    except Exception:
        return None
