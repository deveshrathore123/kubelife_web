from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    consent_analytics = Column(Boolean, default=False)
    entries = relationship("Entry", back_populates="user", cascade="all, delete-orphan")

class Entry(Base):
    __tablename__ = "entries"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    frequency_per_week = Column(Float)
    dosage_mg_per_week = Column(Float)
    cycle_weeks = Column(Integer)
    pct_on_cycle = Column(Boolean)
    side_effects = Column(JSON)
    lifestyle = Column(JSON)
    weight_kg = Column(Float)
    systolic_bp = Column(Integer)
    diastolic_bp = Column(Integer)
    heart_rate_bpm = Column(Integer)
    mood_1_5 = Column(Integer)
    sleep_hours = Column(Float)
    rule_risk_score = Column(Float)
    ml_risk_score = Column(Float)
    risk_band = Column(String)
    user = relationship("User", back_populates="entries")
