from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional

from .database import Base, engine, get_db
from .models import User, Entry
from .schemas import UserCreate, UserOut, EntryIn, EntryOut
from .security import hash_password, verify_password, make_token, decode_token
from .risk import rule_based_score
from .ml_model import MODEL

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Steroid Risk Local API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

@app.post("/auth/register", response_model=UserOut)
def register(p: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == p.email).first():
        raise HTTPException(400, "Email already registered")
    u = User(email=p.email, password_hash=hash_password(p.password), consent_analytics=p.consent_analytics)
    db.add(u); db.commit(); db.refresh(u)
    return u

@app.post("/auth/login")
def login(p: UserCreate, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.email == p.email).first()
    if not u or not verify_password(p.password, u.password_hash):
        raise HTTPException(401, "Invalid credentials")
    return {"access_token": make_token(str(u.id)), "token_type": "bearer"}

def current_user(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)) -> User:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing token")
    sub = decode_token(authorization.split()[1])
    if not sub: raise HTTPException(401, "Invalid token")
    u = db.get(User, int(sub))
    if not u: raise HTTPException(401, "Unknown user")
    return u

@app.post("/ingest/entry", response_model=EntryOut)
def create_entry(data: EntryIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    payload = data.dict()
    rb = rule_based_score(payload)
    ml = MODEL.predict_proba(payload)
    band = rb["band"]
    if ml >= 0.7 and band != "high":
        band = "moderate" if band == "low" else band
    e = Entry(user_id=user.id, rule_risk_score=rb["score"], ml_risk_score=ml, risk_band=band, **payload)
    db.add(e); db.commit(); db.refresh(e)
    return e

@app.get("/analytics/me/summary")
def my_summary(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing token")
    sub = decode_token(authorization.split()[1])
    if not sub: raise HTTPException(401, "Invalid token")
    uid = int(sub)
    q = db.query(Entry).filter(Entry.user_id == uid)
    total = q.count()
    if total == 0:
        return {"total_entries": 0}
    latest = q.order_by(Entry.timestamp.desc()).first()
    return {"total_entries": total, "latest": {"timestamp": latest.timestamp,
            "rule_risk_score": latest.rule_risk_score, "ml_risk_score": latest.ml_risk_score,
            "risk_band": latest.risk_band}}

@app.get("/analytics/population/percentiles")
def population_percentiles(db: Session = Depends(get_db)):
    def percentiles(col):
        vals = [v[0] for v in db.query(col).filter(col.isnot(None)).order_by(col).all()]
        if not vals:
            return {"p10": 0, "p50": 0, "p90": 0}
        import math
        def q(p):
            if len(vals) == 1: return vals[0]
            i = max(0, min(len(vals)-1, int(math.floor(p*(len(vals)-1)))))
            return float(vals[i])
        return {"p10": q(0.1), "p50": q(0.5), "p90": q(0.9)}

    return {
        "dosage_mg_per_week": percentiles(Entry.dosage_mg_per_week),
        "systolic_bp": percentiles(Entry.systolic_bp),
        "diastolic_bp": percentiles(Entry.diastolic_bp),
        "heart_rate_bpm": percentiles(Entry.heart_rate_bpm),
        "sleep_hours": percentiles(Entry.sleep_hours),
        "rule_risk_score": percentiles(Entry.rule_risk_score),
        "ml_risk_score": percentiles(Entry.ml_risk_score),
        "entries": int(db.query(func.count(Entry.id)).scalar() or 0)
    }

@app.get("/")
def root():
    return {"ok": True, "message": "Local API running. See /docs"}
