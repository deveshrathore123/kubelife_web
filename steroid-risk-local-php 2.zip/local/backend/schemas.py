from pydantic import BaseModel, EmailStr, conint, confloat
from typing import Optional, Dict, Any
from datetime import datetime

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    consent_analytics: bool = False

class UserOut(BaseModel):
    id: int
    email: EmailStr
    created_at: datetime
    consent_analytics: bool
    class Config:
        from_attributes = True

class EntryIn(BaseModel):
    frequency_per_week: Optional[confloat(ge=0, le=14)] = 0
    dosage_mg_per_week: Optional[confloat(ge=0, le=5000)] = 0
    cycle_weeks: Optional[conint(ge=0, le=52)] = 0
    pct_on_cycle: Optional[bool] = False
    side_effects: Optional[Dict[str, Any]] = {}
    lifestyle: Optional[Dict[str, Any]] = {}
    weight_kg: Optional[confloat(ge=20, le=300)] = None
    systolic_bp: Optional[conint(ge=70, le=240)] = None
    diastolic_bp: Optional[conint(ge=40, le=150)] = None
    heart_rate_bpm: Optional[conint(ge=30, le=220)] = None
    mood_1_5: Optional[conint(ge=1, le=5)] = None
    sleep_hours: Optional[confloat(ge=0, le=24)] = None

class EntryOut(EntryIn):
    id: int
    timestamp: datetime
    rule_risk_score: Optional[float]
    ml_risk_score: Optional[float]
    risk_band: Optional[str]
    class Config:
        from_attributes = True
